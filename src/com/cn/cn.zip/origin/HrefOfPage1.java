package com.cn.origin;

public class HrefOfPage1  
{  
    /**  
     * ���ҳ��Դ�����г�����  
     */ 
    public static void getHrefOfContent(String content)  
    {  
        System.out.println("��ʼ");  
        String[] contents = content.split("<a href=\"");  
       // String[] contentpart = content.split("<li class=\"commit commits-list-item ");
        //System.out.println(contentpart.length);
        System.out.println(contents.length);
      //  System.out.println(contentpart[1]);
        String[] aHref = new String[10];
        for (int i = 1; i < contents.length; i++)  
        {  
            int endHref = contents[i].indexOf("\"");  
 
          // String  aHref = FunctionUtils.getHrefOfInOut(contents[i].substring( 0,endHref));  
           aHref[i] = FunctionUtils.getHrefOfInOut(contents[i].substring( 0,endHref));  
            System.out.println(aHref[i]);
       
        }  
 
       
 
    }  
 
} 