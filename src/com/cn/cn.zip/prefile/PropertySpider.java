package com.cn.prefile;

public class PropertySpider {
	private String sign  = null;
	private String author;
	private String time;
	private String inhref;
	private String title;
	
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getInhref() {
		return inhref;
	}
	public void setInhref(String inhref) {
		this.inhref = inhref;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	

}
